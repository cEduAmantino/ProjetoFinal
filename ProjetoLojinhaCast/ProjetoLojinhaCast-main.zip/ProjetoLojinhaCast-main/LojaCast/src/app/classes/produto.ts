export class Produto {
  nomeProduto!: string;
  descricaoProduto!: string;
  precoProduto!: number;
  descontoProduto!: number;
}
