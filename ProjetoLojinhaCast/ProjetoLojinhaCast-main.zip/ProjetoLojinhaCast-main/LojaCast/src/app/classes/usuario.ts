export class Usuario {
  id!:number;
  nome!:string;
  cpf!:number;
  email!:string;
}
