import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
@Component({
  selector: 'app-descricao-produto3',
  templateUrl: './descricao-produto3.component.html',
  styleUrls: ['./descricao-produto3.component.css']
})
export class DescricaoProduto3Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
