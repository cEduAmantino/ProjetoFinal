import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
@Component({
  selector: 'app-descricao-produto4',
  templateUrl: './descricao-produto4.component.html',
  styleUrls: ['./descricao-produto4.component.css']
})
export class DescricaoProduto4Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
