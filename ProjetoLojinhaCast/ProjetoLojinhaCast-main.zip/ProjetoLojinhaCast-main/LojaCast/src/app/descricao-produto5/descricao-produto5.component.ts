import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-descricao-produto5',
  templateUrl: './descricao-produto5.component.html',
  styleUrls: ['./descricao-produto5.component.css']
})
export class DescricaoProduto5Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
