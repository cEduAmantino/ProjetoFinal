import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-descricao-produto6',
  templateUrl: './descricao-produto6.component.html',
  styleUrls: ['./descricao-produto6.component.css']
})
export class DescricaoProduto6Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
