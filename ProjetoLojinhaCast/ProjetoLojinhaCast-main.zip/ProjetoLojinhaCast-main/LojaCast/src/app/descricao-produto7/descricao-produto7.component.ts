import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-descricao-produto7',
  templateUrl: './descricao-produto7.component.html',
  styleUrls: ['./descricao-produto7.component.css']
})
export class DescricaoProduto7Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
