import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
@Component({
  selector: 'app-descricao-produto8',
  templateUrl: './descricao-produto8.component.html',
  styleUrls: ['./descricao-produto8.component.css']
})
export class DescricaoProduto8Component implements OnInit {

  panelOpenState = false;
  
  constructor() { }

  ngOnInit(): void {
  }

}
