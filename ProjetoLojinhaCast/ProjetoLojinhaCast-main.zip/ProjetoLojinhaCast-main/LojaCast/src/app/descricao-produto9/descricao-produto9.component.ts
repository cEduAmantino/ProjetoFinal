import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
@Component({
  selector: 'app-descricao-produto9',
  templateUrl: './descricao-produto9.component.html',
  styleUrls: ['./descricao-produto9.component.css']
})
export class DescricaoProduto9Component implements OnInit {
  panelOpenState = false;

  constructor() { }

  ngOnInit(): void {
  }

}
