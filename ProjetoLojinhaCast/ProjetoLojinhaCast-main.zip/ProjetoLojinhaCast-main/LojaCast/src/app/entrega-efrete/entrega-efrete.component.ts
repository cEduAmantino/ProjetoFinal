import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrega-efrete',
  templateUrl: './entrega-efrete.component.html',
  styleUrls: ['./entrega-efrete.component.css']
})
export class EntregaEfreteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
