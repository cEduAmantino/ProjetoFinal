import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-politica-etroca',
  templateUrl: './politica-etroca.component.html',
  styleUrls: ['./politica-etroca.component.css']
})
export class PoliticaEtrocaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
