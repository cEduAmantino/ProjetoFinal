import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuario-delete',
  templateUrl: './usuario-delete.component.html',
  styleUrls: ['./usuario-delete.component.css']
})
export class UsuarioDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
