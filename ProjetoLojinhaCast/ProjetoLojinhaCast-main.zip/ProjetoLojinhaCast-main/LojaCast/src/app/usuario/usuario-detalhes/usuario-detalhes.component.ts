import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuario-detalhes',
  templateUrl: './usuario-detalhes.component.html',
  styleUrls: ['./usuario-detalhes.component.css']
})
export class UsuarioDetalhesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
